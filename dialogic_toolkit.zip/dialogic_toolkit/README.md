Welcome to your QAT-Kit.

Load the `toolkit.json` file. Choose a tool by name. Follow its `instructions`.

To use:  
“Please run `StressTest` on this idea: ______”

To extend:  
Add new entries to the `tools:` array in the YAML file.
